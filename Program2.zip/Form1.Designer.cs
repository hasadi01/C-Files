﻿
namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.textBoxPeople = new System.Windows.Forms.TextBox();
            this.textBoxDistance = new System.Windows.Forms.TextBox();
            this.textBoxDeliveryDays = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelLowestCost = new System.Windows.Forms.Label();
            this.labelCCost = new System.Windows.Forms.Label();
            this.labelBCost = new System.Windows.Forms.Label();
            this.labelACost = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "People:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Distance (Miles):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "Delivery Days:";
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Location = new System.Drawing.Point(50, 329);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(198, 41);
            this.buttonCalculate.TabIndex = 6;
            this.buttonCalculate.Text = "Calculate Cost";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // textBoxPeople
            // 
            this.textBoxPeople.Location = new System.Drawing.Point(243, 65);
            this.textBoxPeople.Name = "textBoxPeople";
            this.textBoxPeople.Size = new System.Drawing.Size(100, 31);
            this.textBoxPeople.TabIndex = 7;
            // 
            // textBoxDistance
            // 
            this.textBoxDistance.Location = new System.Drawing.Point(243, 152);
            this.textBoxDistance.Name = "textBoxDistance";
            this.textBoxDistance.Size = new System.Drawing.Size(100, 31);
            this.textBoxDistance.TabIndex = 8;
            // 
            // textBoxDeliveryDays
            // 
            this.textBoxDeliveryDays.Location = new System.Drawing.Point(243, 239);
            this.textBoxDeliveryDays.Name = "textBoxDeliveryDays";
            this.textBoxDeliveryDays.Size = new System.Drawing.Size(100, 31);
            this.textBoxDeliveryDays.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labelLowestCost);
            this.panel1.Controls.Add(this.labelCCost);
            this.panel1.Controls.Add(this.labelBCost);
            this.panel1.Controls.Add(this.labelACost);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(435, 98);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(415, 393);
            this.panel1.TabIndex = 10;
            this.panel1.Tag = "";
            // 
            // labelLowestCost
            // 
            this.labelLowestCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelLowestCost.Location = new System.Drawing.Point(32, 305);
            this.labelLowestCost.Name = "labelLowestCost";
            this.labelLowestCost.Size = new System.Drawing.Size(352, 39);
            this.labelLowestCost.TabIndex = 6;
            // 
            // labelCCost
            // 
            this.labelCCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelCCost.Location = new System.Drawing.Point(237, 184);
            this.labelCCost.Name = "labelCCost";
            this.labelCCost.Size = new System.Drawing.Size(110, 38);
            this.labelCCost.TabIndex = 5;
            // 
            // labelBCost
            // 
            this.labelBCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelBCost.Location = new System.Drawing.Point(237, 121);
            this.labelBCost.Name = "labelBCost";
            this.labelBCost.Size = new System.Drawing.Size(110, 37);
            this.labelBCost.TabIndex = 4;
            // 
            // labelACost
            // 
            this.labelACost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelACost.Location = new System.Drawing.Point(237, 62);
            this.labelACost.Name = "labelACost";
            this.labelACost.Size = new System.Drawing.Size(110, 36);
            this.labelACost.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 197);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(180, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "Company C Cost:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(179, 25);
            this.label6.TabIndex = 1;
            this.label6.Text = "Company B Cost:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(179, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Company A Cost:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(452, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 25);
            this.label2.TabIndex = 11;
            this.label2.Text = "Results";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 589);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBoxDeliveryDays);
            this.Controls.Add(this.textBoxDistance);
            this.Controls.Add(this.textBoxPeople);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Food Delivery Cost Calculation";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.TextBox textBoxPeople;
        private System.Windows.Forms.TextBox textBoxDistance;
        private System.Windows.Forms.TextBox textBoxDeliveryDays;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelLowestCost;
        private System.Windows.Forms.Label labelCCost;
        private System.Windows.Forms.Label labelBCost;
        private System.Windows.Forms.Label labelACost;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
    }
}

