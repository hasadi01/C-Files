﻿//Grading ID: R1028
//CIS 199-01
//Due Date: 03/11/2021
//This program calculates the lowest cost company based on price inputs for number of people, distance in miles, and number of days to pepare delivery.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int people, deliveryDays; //variables for input people and delivery days
            double distance; //variables for input distance (in miles)

            //we need to parse user's input into variables for further calculations; display error message if invalid input.
            if (!int.TryParse(textBoxPeople.Text, out people) || people <= 0)
                MessageBox.Show("Please input a valid number for people (must be positive whole number).");

            else if (!int.TryParse(textBoxDeliveryDays.Text, out deliveryDays) || deliveryDays <= 0)
                MessageBox.Show("Please input a valid number for delivery (must be positive whole number).");

            else if (!double.TryParse(textBoxDistance.Text, out distance) || distance <= 0)
                MessageBox.Show("Please input a valid number for distance (must be positive number).");

            else
            {
                double costA, costB, costC; //variables for total cost charged for companies A, B, and C.


                const double costPerPersonA = 1.00; //variable for Company A cost per person
                const double costPerMileA = 0.02; //variable for Company A cost per distance in miles
                double costDeliveryDaysA; //variable for Company A cost per delivery days
                                 
                //switch statement to determine cost for delivery days for Company A
                switch (deliveryDays)
                {
                    case 1:
                        costDeliveryDaysA = 20.00;
                        break;
                    case 2:
                        costDeliveryDaysA = 17.00;
                        break;
                    case 3:
                        costDeliveryDaysA = 15.00;
                        break;
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        costDeliveryDaysA = 10.00;
                        break;
                    default:
                        costDeliveryDaysA = 7.00;
                        break;
                }
                //calculate the cost for Company A
                costA = people * costPerPersonA + distance * costPerMileA + costDeliveryDaysA;

                
                double costPerPersonB; //variable for Company B cost per person

                //if statement to determine cost per person for company B
                if (people < 10)
                    costPerPersonB = 20.00;
                else if (people < 50)
                    costPerPersonB = 10.00;
                else if (people < 100)
                    costPerPersonB = 5.00;
                else if (people < 200)
                    costPerPersonB = 3.00;
                else
                    costPerPersonB = 0.15;

                const double costPerMileB = 0.10; //variable for Company B cost per distance in miles
                int costDeliveryDaysB = deliveryDays < 5 ? 10 : 7; //variable for Company B delivery days (test in tertiary operation)

                //calculate the cost for Company B
                costB = people * costPerPersonB + distance * costPerMileB + costDeliveryDaysB;

                const double costPerPersonC = 0.25; //variable for Company C cost per person
                int costDistanceC; //variable for Company C cost per distance 

                //if statement to determine distance cost for Company C
                if (distance >= 1000)
                    costDistanceC = 40;
                else if (distance >= 750)
                    costDistanceC = 35;
                else if (distance >= 500)
                    costDistanceC = 25;
                else if (distance >= 200)
                    costDistanceC = 15;
                else
                    costDistanceC = 10;

                const int costDeliveryDaysC = 20; //variable for Company C delivery days

                //calculate the cost for Company C
                costC = people * costPerPersonC + costDistanceC + costDeliveryDaysC;

                //display the calculations in the corresponding labels
                labelACost.Text = costA.ToString("C");
                labelBCost.Text = costB.ToString("C");
                labelCCost.Text = costC.ToString("C");

                //find and display the lowest cost company
                string lowestCostCompany;

                if (costA < costB && costA < costC)
                    lowestCostCompany = "A";
                else if (costB < costC)
                    lowestCostCompany = "B";
                else
                    lowestCostCompany = "C";

                labelLowestCost.Text = $"The lowest cost company is {lowestCostCompany}.";
            }
        }

        
    }
}
