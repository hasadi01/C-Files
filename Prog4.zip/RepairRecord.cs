﻿//Repair Record class declaration with a constructor
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog4
{
    class RepairRecord
    {
        //backing fields
        private int _serviceLocationZipCode; //between 00000 and 99999
        private string _makeModel; //any string for make and model
        private string _serialNumber; //10 character length (string)
        private int _modelYear; //any int for model year
        private int _apptLength; //between 15 and 180 minutes
        private string _technicianName; //any string for technician name
        private bool _warranty; //is there warranty coverage 

        //next are the properties for each
        public int ServiceLocationZipCode
        {
            //precondition: none
            //postcondition: return service location zipcode
            get
            {
                return _serviceLocationZipCode;
            }
            //precondition: 00000<=value<=99999
            //postcondition: service location zipcode has been set to specified value
            set
            {
                if (value >= 00000 && value <= 99999)
                    _serviceLocationZipCode = value;
                else //default value is 40204
                    _serviceLocationZipCode = 40204;
            }

        }
        public string MakeModel
        {
            //precondition: none
            //postcondition: return make and model
            get
            {
                return _makeModel;
            }
            //precondition: make and model cannot be white space
            //postcondition: make and model has been set to value
            set
            {
                if (!String.IsNullOrWhiteSpace(value))
                    _makeModel = value;
                else //default is "unkown male/model"
                    _makeModel = "Unkown Make/Model";
            }
        }

        public string SerialNumber
        {
            //precondition: none
            //postcondition: return serial number
            get
            {
                return _serialNumber;
            }
            //precondition: serial number is 10 characters in length
            //postcondition: serial number set to value
            set
            {
                if (value.Length == 10)
                    _serialNumber = value;
                else //default string is A000000000
                    _serialNumber = "A000000000";
            }
        }

        //property for technician name (cannot have blank space)
        public string TechnicianName
        {
            //precondition: none
            //postcondition: return technician name
            get
            {
                return _technicianName;
            }
            //precondition: technician name cannot be white space
            //postcondition: technician name set to value
            set
            {
                if (!String.IsNullOrWhiteSpace(value))
                    _technicianName = value;
                else
                    _technicianName = "John Smith";
            }
        }

        public int AppointmentLength
        {
            //precondition: none
            //postcondition: return appointment length (in minutes)
            get
            {
                return _apptLength;
            }
            //precondition: 15<=value<=180
            //postcondition: appointment length has been set to specified value
            set
            {
                if (value >= 15 && value <= 180)
                    _apptLength = value;
                else //default value is 30
                    _apptLength = 30;
            }
        }
        public int ModelYear
        {
            //precondition: none
            //postcondition: return model year
            get
            {
                return _modelYear;
            }
            //precondition: none
            //postcondition: model year set to value
            set
            {
                _modelYear = value;
            }
        }
        public bool WarrantyCoverage
        {
            //precondition: none
            //postcondition: return warrany coverage
            get
            {
                return _warranty;
            }
            //precondition: none
            //postcondition: warranty coverage set to value
            set
            {
                _warranty = value;
            }
        }
        //constructor
        //precondition:
        //      zipcode between 00000 and 99999
        //      make and model: none
        //      serial number: 10 characters
        //      model year: none
        //      technician name: none
        //      warranty coverage: none
        //postcondition: object created and values assigned
        public RepairRecord(int serviceLocationZipCode, string makeModel, string serialNumber, int modelYear, int apptLength, string technicianName, bool warrantyCoverage)
        {
            ServiceLocationZipCode = serviceLocationZipCode; //set the property for the service location zipcode
            MakeModel = makeModel; //set the property for the make and model
            SerialNumber = serialNumber; //set the property for the serial number
            ModelYear = modelYear; //set the property for the model year
            TechnicianName = technicianName; //set the property for the technician name
            WarrantyCoverage = warrantyCoverage; //set the property for the warranty coverage
        }

        //method for calculation cost
        //precondition: none
        //postcondition: returns cost calculated
        public double CalcCost()
        {
            double cost;
            const double flatFee = 25;
            const double perMinuteService = 1.50;
            if (!WarrantyCoverage)
            { cost = 20; } //default is 20 if coverage is false
            else
            { cost = AppointmentLength * perMinuteService + flatFee; }
            return cost;
        }
        public double AppointmentHours
        {
            //precondition: none
            //postcondition: return appointment hours
            get
            {
                double _apptHours = _apptLength / 60; //there are 60 minutes in an hour
                return _apptHours;
            }
            //read-only, no setter
        }
        //precondition: none
        //postcondition: return string for each repair record
        public override string ToString()
        {
            return 
                $"Service Location ZipCode: {ServiceLocationZipCode}\n" +
                $"Year: {ModelYear}\n" +
                $"Make and Model: {MakeModel}\n" +
                $"Serial Number: {SerialNumber}\n" +
                $"Appointment Length: {AppointmentLength}\n" +
                $"Appointment Hours: {AppointmentHours}\n" +
                $"Technician name: {TechnicianName}\n" +
                $"Warranty Coverage? {WarrantyCoverage}\n" +
                $"Calculate Cost Ouput: {CalcCost()}";
            
        }
    }
}
