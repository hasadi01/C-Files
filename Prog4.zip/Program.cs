﻿//Grading ID: R1028
//CIS 199-01
//Due Date: 4/18/2021
//Program 4
//This program displays the repair records costs for 6 different repairs (and then the updated repairs with mew properties)
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Prog4
{
    class Program
    {
        //precondition: array of object is initialized
        //postcondition: reports for each repair displayed in console
        public static void OutputRepairRecords (RepairRecord[] repairRecords) 
        {
            foreach(RepairRecord repairRecord in repairRecords)
            {
                WriteLine(repairRecord.ToString());
                WriteLine();
            }
        }

        //precondition: none
        //postcondition: run program
        static void Main(string[] args)
        {
            RepairRecord[] repairRecords = new RepairRecord[]
            {
                //each line initializes an instance of the object and adds to it to the array
                new RepairRecord(40208, "Volvo s60", "A883838374", 2008, 50, "Steve Harvey", true), 
                new RepairRecord(40222, "Volvo xc60", "A274727362", 2016, 100, "Danny Devito", false),
                new RepairRecord(40205, "Volvo xc90", "A321232872", 2020, 46, "John Doe", false),
                new RepairRecord(40203, "Volvo s40", "A377448824", 2004, 70, "Ama Zulu", false),
                new RepairRecord(40214, "Volvo xc40", "A388992364", 2010, 92, "Bob Marley", true),
                new RepairRecord(40208, "Volvo s80", "A118227376", 2003, 45, "Lenny Kravitz", false)
            };

            OutputRepairRecords(repairRecords); //calling method
            WriteLine("____________________________"); //this is to separate them
            repairRecords[0].SerialNumber = "A729738276"; //for each position, change one property
            repairRecords[1].ModelYear = 2017;
            repairRecords[2].TechnicianName = "Harry Belafonte";
            repairRecords[3].ModelYear = 2006;
            repairRecords[4].AppointmentLength = 95;
            repairRecords[5].WarrantyCoverage = true;
            OutputRepairRecords(repairRecords); //call method again to display new properties
        }
    }
}
