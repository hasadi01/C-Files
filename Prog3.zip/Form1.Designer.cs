﻿
namespace Prog3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxFarm = new System.Windows.Forms.ComboBox();
            this.textBoxItemInput = new System.Windows.Forms.TextBox();
            this.textBoxQuantityInput = new System.Windows.Forms.TextBox();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelInitialCostOutput = new System.Windows.Forms.Label();
            this.labelDiscCostOutput = new System.Windows.Forms.Label();
            this.labelShipCostOutput = new System.Windows.Forms.Label();
            this.labelTotalPriceOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Farm:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 133);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Item:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 198);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantity (lbs):";
            // 
            // comboBoxFarm
            // 
            this.comboBoxFarm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFarm.FormattingEnabled = true;
            this.comboBoxFarm.Items.AddRange(new object[] {
            "NE",
            "NW",
            "SE",
            "SW"});
            this.comboBoxFarm.Location = new System.Drawing.Point(256, 56);
            this.comboBoxFarm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxFarm.Name = "comboBoxFarm";
            this.comboBoxFarm.Size = new System.Drawing.Size(120, 33);
            this.comboBoxFarm.TabIndex = 3;
            // 
            // textBoxItemInput
            // 
            this.textBoxItemInput.Location = new System.Drawing.Point(256, 119);
            this.textBoxItemInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxItemInput.Name = "textBoxItemInput";
            this.textBoxItemInput.Size = new System.Drawing.Size(120, 31);
            this.textBoxItemInput.TabIndex = 4;
            // 
            // textBoxQuantityInput
            // 
            this.textBoxQuantityInput.Location = new System.Drawing.Point(256, 185);
            this.textBoxQuantityInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxQuantityInput.Name = "textBoxQuantityInput";
            this.textBoxQuantityInput.Size = new System.Drawing.Size(120, 31);
            this.textBoxQuantityInput.TabIndex = 5;
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Location = new System.Drawing.Point(130, 258);
            this.buttonCalculate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(138, 46);
            this.buttonCalculate.TabIndex = 6;
            this.buttonCalculate.Text = "Calculate";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 338);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Initial Cost:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(46, 402);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Discounted Cost:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 465);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "Shipment Cost:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 527);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "Total Price:";
            // 
            // labelInitialCostOutput
            // 
            this.labelInitialCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelInitialCostOutput.Location = new System.Drawing.Point(250, 338);
            this.labelInitialCostOutput.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelInitialCostOutput.Name = "labelInitialCostOutput";
            this.labelInitialCostOutput.Size = new System.Drawing.Size(128, 42);
            this.labelInitialCostOutput.TabIndex = 15;
            // 
            // labelDiscCostOutput
            // 
            this.labelDiscCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDiscCostOutput.Location = new System.Drawing.Point(250, 402);
            this.labelDiscCostOutput.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelDiscCostOutput.Name = "labelDiscCostOutput";
            this.labelDiscCostOutput.Size = new System.Drawing.Size(128, 42);
            this.labelDiscCostOutput.TabIndex = 16;
            // 
            // labelShipCostOutput
            // 
            this.labelShipCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelShipCostOutput.Location = new System.Drawing.Point(250, 465);
            this.labelShipCostOutput.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelShipCostOutput.Name = "labelShipCostOutput";
            this.labelShipCostOutput.Size = new System.Drawing.Size(128, 42);
            this.labelShipCostOutput.TabIndex = 17;
            // 
            // labelTotalPriceOutput
            // 
            this.labelTotalPriceOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTotalPriceOutput.Location = new System.Drawing.Point(250, 525);
            this.labelTotalPriceOutput.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelTotalPriceOutput.Name = "labelTotalPriceOutput";
            this.labelTotalPriceOutput.Size = new System.Drawing.Size(128, 42);
            this.labelTotalPriceOutput.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 619);
            this.Controls.Add(this.labelTotalPriceOutput);
            this.Controls.Add(this.labelShipCostOutput);
            this.Controls.Add(this.labelDiscCostOutput);
            this.Controls.Add(this.labelInitialCostOutput);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.textBoxQuantityInput);
            this.Controls.Add(this.textBoxItemInput);
            this.Controls.Add(this.comboBoxFarm);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Program 3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxFarm;
        private System.Windows.Forms.TextBox textBoxItemInput;
        private System.Windows.Forms.TextBox textBoxQuantityInput;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelInitialCostOutput;
        private System.Windows.Forms.Label labelDiscCostOutput;
        private System.Windows.Forms.Label labelShipCostOutput;
        private System.Windows.Forms.Label labelTotalPriceOutput;
    }
}

