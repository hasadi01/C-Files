﻿//ID: R1028
//CIS 199-01
//Program 3
//4/01/2021
//This program calculates the initial cost, discount cost, shipment cost, and total cost for each farm selected.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Prog3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //function that tests if something is selected
        private bool IsFarmValid()
        {
            return comboBoxFarm.SelectedIndex >= 0;
        }
        //function tests if entered integer is between 10001 and 10007
        private bool IsItemNumberValid()
        {
            int itemNumber;
            if (Int32.TryParse(textBoxItemInput.Text, out itemNumber))
            {
                return itemNumber >= 10001 && itemNumber <= 10007;
            }
            else
            { 
                return false;
            }

        }
        //function that tests if entered quantity is valid (greater than zero)
        private bool IsQuantityValid()
        {
            int quantity;
            if (Int32.TryParse(textBoxQuantityInput.Text, out quantity))
            {
                return quantity > 0;
            }
            else
            {
                return false;
            }
        }
        //function that finds the position of the entered item number
        private int ItemPosition(int itemNumber)
        {
            int[] itemNumbers = { 10001, 10002, 10003, 10004, 10005, 10006, 10007 };
            for (int i=0; i<itemNumbers.Length; i++)
            {
                if(itemNumber==itemNumbers[i])
                {
                    return i;
                }
            }
            return -1; //if it's not found, then return -1
        }
        //function that calculates initial cost
        private double InitialCost(int itemPosition, int quantity)
        {
            double[] costPerPound = { 7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 };
            return quantity * costPerPound[itemPosition];
        }
        //function that finds discount based on quantity
        private double Discount(int quantity)
        {
            int[] poundLowLimit = { 0, 6, 11, 21 };
            double[] discount = { .00, .05, .10, .15 };

            int i = poundLowLimit.Length - 1;
            while (i >= 0 && quantity < poundLowLimit[i])
            {
                i--;
            }
            return discount[i];
        }
        //function that calculates dicounted cost
        private double DiscountedCost(double initialCost, double discount)
        {
            return initialCost - initialCost * discount;
        }
        //function that calculates shipment cost
        private double ShipmentCost(int selectedFarm, double discountedCost)
        {
            double[] shipFee = { 0.06, 0.0717, 0.07, 0.0874 };
            return shipFee[selectedFarm]*discountedCost;
        }
        //event handler
        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            //if statement: if there are any invalid inputs, then show error message
            //else, calculate and output calculations
            if (!IsFarmValid())
            {
                MessageBox.Show("Please select farm.");
            }
            else if (!IsItemNumberValid())
            {
                MessageBox.Show("Please enter item number between 10001 and 10007.");
            }
            else if (!IsQuantityValid())
            {
                MessageBox.Show("Please enter valid integer quantity.");
            }
            else
            {
                //parse values
                int itemNumber = Int32.Parse(textBoxItemInput.Text);
                int quantity = Int32.Parse(textBoxQuantityInput.Text);

                //finding positions and calculations
                int itemPosition = ItemPosition(itemNumber);
                double initialCost = InitialCost(itemPosition, quantity);
                double discountCost = DiscountedCost(initialCost, Discount(quantity));
                double shipmentCost = ShipmentCost(comboBoxFarm.SelectedIndex, discountCost);
                double totalPrice = discountCost + shipmentCost;

                //display as currencies
                labelInitialCostOutput.Text = $"{initialCost:C}";
                labelDiscCostOutput.Text = $"{discountCost:C}";
                labelShipCostOutput.Text = $"{shipmentCost:C}";
                labelTotalPriceOutput.Text = $"{totalPrice:C}";
                    
            }


            

            


        }
    }
}
