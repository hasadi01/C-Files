﻿//Grading ID: R1028
//CIS 199-01
//Due Date: 02/16/2021
//This program calculates the Soil Cost, Labor Cost, Fertilizer Cost, and Total Cost for customer at ABC Landscaping & garden Desgin Estimating Service.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Prog1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Hello! Welcome to the ABC Lanscaping & Garden Design Estimating Service.");
            WriteLine();

            const double Labor_Cost_Per_Yd = 3.25; //Labor cost per yard is $3.25
            const double Fertilizer_Cost_Per_Yd = 4.25; //Fertilizer cost per yard is $4.25
            const double SQ_Ft_In_SQ_Yd = 9.0; //There are 9 SQ. Feet in 1 SQ. yard
            const double Waste_Factor = 1.1; //Ten percent soil waste 
            const double First_Garden_Cost = 50.0; //Additional $50 labor fee for first garden

            double width; //variable for width in feet
            double length; //variable for length in feet
            double price; //price of soil per SQ. yard

            Write("Enter max width of the garden (in feet): "); 
            string widthInput = ReadLine();
            width = Convert.ToDouble(widthInput); //converts string to double for input width in feet
            
            Write("Enter the max length of the garden (in feet): ");
            string lengthInput = ReadLine();
            length = Convert.ToDouble(lengthInput); //converts string to double for input length in feet

            Write("Enter soil price (per sq. yard): ");
            string priceInput = ReadLine();
            price = Convert.ToDouble(priceInput); //converts string to double for input price per SQ. yard

            WriteLine();

            int fertilizer; //variable for whether fertilizer will be used; 1 = Yes, 0 = No
            Write("Would you like additional fertilizer? Enter 1 for 'Yes' or 0 for 'No': ");
            string fertInput = ReadLine();
            fertilizer = Convert.ToInt32(fertInput); //converts string to double for input yes or no
            
            int firstGarden; //variable for whether it is first garden; 1 = Yes, 0 = No
            Write("Is this your first garden with our company? Enter 1 for 'Yes' or 0 for 'No': ");
            string fstGardenInput = ReadLine();
            firstGarden = Convert.ToInt32(fstGardenInput); //converts string to double for input yes or no

            WriteLine();

            double area = (width * length) / SQ_Ft_In_SQ_Yd; //calculates the area (from feet to SQ. yard)
            double soilCost = area * Waste_Factor * price; //calculates the soil cost (including 10% for soil waste)
            double laborCost = area * Labor_Cost_Per_Yd; //calculates the labor cost

            if (firstGarden == 1) 
                laborCost += First_Garden_Cost; //if it is first garden, fee of $50 is added to labor cost

            double fertCost;
            if (fertilizer == 1)
                fertCost = area * Fertilizer_Cost_Per_Yd; //if fertilizer is used, cost is calculated based on area
            else
                fertCost = 0.0; //if fertilizer is not used, there is no cost

            double totalCost = soilCost + laborCost + fertCost; //calculates total cost

            //final output is written
            WriteLine("SQ. Yards Needed: {0}", area.ToString("F1")); 
            WriteLine("Soil Cost: {0}", soilCost.ToString("C"));
            WriteLine("Fertilizer Cost: {0}", fertCost.ToString("C"));
            WriteLine("Labor Cost: {0}", laborCost.ToString("C"));
            WriteLine("Total Cost: {0}", totalCost.ToString("C"));
            

            
            
           











        }
    }
}
